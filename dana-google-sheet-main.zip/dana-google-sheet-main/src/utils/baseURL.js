const BASE_URL = 'https://m.dana.id';

export const PROFILE_ENDPOINT = BASE_URL + '/wallet/api/alipayplus.mobilewallet.user.information.more.json';
export const TRANSACTION_ENDPOINT = BASE_URL + '/wallet/api/alipayplus.mobilewallet.user.transaction.list.json?ctoken=huW4juT-CnpS8nWl';
export const TRX_DETAIL_ENDPOINT = BASE_URL + '/wallet/api/alipayplus.mobilewallet.user.transaction.detail.json';