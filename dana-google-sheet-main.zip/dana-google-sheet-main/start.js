import dotenv from 'dotenv';
import { google } from 'googleapis';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { spawn } from 'child_process';
import cron from 'node-cron';
import inquirer from 'inquirer';
import { getProfile } from './src/function/getProfile.js';
import { getTrxDetails } from './src/function/getDetailTrx.js';
import { getTrxHistory } from './src/function/getTransaction.js';
dotenv.config();


const SHEET_NAME = 'Dana';
let SPREADSHEET_ID;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CREDENTIALS_PATH = path.join(__dirname, 'cred.json');

const auth = new google.auth.GoogleAuth({
    keyFile: CREDENTIALS_PATH,
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
});

const questions = [
    {
        type: 'input',
        name: 'sheetId',
        message: 'Enter the Google Sheet ID:',
        validate: function (value) {
            var pass = value.match(/^[a-zA-Z0-9-_]+$/);
            if (pass) {
                return true;
            }
            return 'Google Sheet ID.';
        }
    }
];

const answers = await inquirer.prompt(questions);
SPREADSHEET_ID = answers.sheetId;

async function updateDataInSheet(auth, range, values) {
    const sheets = google.sheets({ version: 'v4', auth });
    await sheets.spreadsheets.values.update({
        spreadsheetId: SPREADSHEET_ID,
        range: range,
        valueInputOption: 'USER_ENTERED',
        resource: {
            values: values,
        },
    });
}
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
async function getDataFromSheet(auth, range) {
    const sheets = google.sheets({ version: 'v4', auth });
    const response = await sheets.spreadsheets.values.get({
        spreadsheetId: SPREADSHEET_ID,
        range: range,
    });
    return response.data.values || [];
}
async function appendDataToSheet(auth, range, values) {
    const sheets = google.sheets({ version: 'v4', auth });
    await sheets.spreadsheets.values.append({
        spreadsheetId: SPREADSHEET_ID,
        range: range,
        valueInputOption: 'USER_ENTERED',
        resource: {
            values: values,
        },
    });
}

async function firstRun(sessionId) {
    try {
        const client = await auth.getClient();
        const cookie = sessionId;
        const profile = await getProfile(cookie);
        const trxHistory = await getTrxHistory(cookie);
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth(); // 0-11, where 0 is January and 11 is December
        const namaDana = profile.result.nickname;
        const profileData = [['Last Balance:', profile.result.balanceDisplay.amount]];
        await updateDataInSheet(client, `${SHEET_NAME}!B2`, profileData);

        const existingTransactions = await getDataFromSheet(client, `${SHEET_NAME}!B5:B`);
        const existingBizOrderIds = existingTransactions.flat();

        for (const trx of trxHistory.result.transactionListItemDTOs) {
            //console.log(trx);
            if (!existingBizOrderIds.includes(trx.bizOrderId)) {
                const transactionDate = new Date(trx.orderCreatedTime);
                const transactionMonth = transactionDate.getMonth();
        
              //  if (transactionMonth === currentMonth) {
                    const detail = await getTrxDetails(cookie, trx.bizOrderId, trx.paymentOrderId);
                    let name = detail.result?.transactionDetailItemDTO?.orderTitle ? extractMandiriMutationName(detail.result.transactionDetailItemDTO.orderTitle) ?? detail.result.transactionDetailItemDTO.orderTitle : "";
        
                    let nominal = "";
                    let keluar = "";
                    if (trx.inOut === 'IN') {
                        nominal = formatAmount(trx.totalAmount?.amount ?? "");
                    } else if (trx.inOut === 'OUT') {
                        keluar = formatAmount(trx.totalAmount?.amount ?? "");
                    }
        
                    const transactionData = [[
                        namaDana,
                        trx.bizOrderId,
                        trx.bizOrderType,
                        transactionDate.toISOString(), 
                        new Date().toISOString(), 
                        detail.result?.transactionDetailItemDTO?.instName ?? "",
                        trx.orderTitle,
                        name,
                        nominal,
                        keluar
                        // Exclude the cost from the array
                    ]];
                    await appendDataToSheet(client, `${SHEET_NAME}!A5:K`, transactionData); // Adjust the range if necessary
                    await sleep(5000);
              //  }
            }
        }
    } catch (error) {
        console.error(error);
    }
}

const formatAmount = (amount) => {
    return amount.replace('.', ',');
};
function extractMandiriMutationName(name) {
    const regex = /(?:ke|dari)(.+)/;
    const match = name.match(regex);
    return match ? match[1] : null;
}

function execShellCommand(cmd, args = []) {
    return new Promise((resolve, reject) => {
        const child = spawn(cmd, args, { shell: true });
        let foundSessionId = false;

        child.stdout.on('data', (data) => {
            if (!foundSessionId) {
                const sessionIdPattern = /ALIPAYJSESSIONID=([A-Z0-9]+danabizplugin[A-Z0-9]+)/;
                const match = data.toString().match(sessionIdPattern);
                if (match) {
                    foundSessionId = true;
                    child.kill();
                    resolve(match[1]);
                    return;
                }
            }
        });
    });
}


async function runFridaScriptFirst() {
    try {
        console.log('Running Frida script on id.dana...');
        const output = await execShellCommand('frida -H 127.0.0.1 -f id.dana -l bypass.js');
        await firstRun(output);
        console.log('SESSION ID: ' + output + '\n');
        return true;
    } catch (error) {
        console.log(error);
        console.log('Failed to run Frida script on id.dana.');
        return false;
    }
}

// runFridaScriptFirst().then(success => {
//     if (success) {
//         setInterval(() => {
//             runFridaScriptFirst().catch(console.error); // Added catch for potential errors
//         }, 30000);
//         console.log('Interval set for 10 seconds.');
//     }
// });

firstRun("GZ00415AD0CC38B644E898762082C46AB931danabizpluginGZ00")